<template>
  <div>
    <el-container>
      <el-header><PageHeader :data="userinfo" /></el-header>
      <el-main>
        <div class="content">
          <div class="center">
            <nuxt />
          </div>
        </div>
      </el-main>
      <el-footer><Footer /></el-footer>
    </el-container>
  </div>
</template>
<script>
export default {
  asyncData(content) {},
  head() {
    return {
      //link: [{ rel: "stylesheet", href: "/css/title.css" }],
    };
  },
};
</script>
