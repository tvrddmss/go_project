
<template>
  <nuxt />
</template>

<script>
export default {
  //使用middleware引入中间件
  middleware: "auth",
};
</script>