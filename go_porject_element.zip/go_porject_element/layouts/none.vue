<template>
  <nuxt />
</template>
<script>
export default {
  head() {
    return {
      link: [{ rel: "stylesheet", href: "/css/none.css" }],
    };
  },
};
</script>
<style scoped>
</style>
