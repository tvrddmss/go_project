import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _84e2427e = () => interopDefault(import('../pages/login.vue' /* webpackChunkName: "pages/login" */))
const _80b033f0 = () => interopDefault(import('../pages/article/creat.vue' /* webpackChunkName: "pages/article/creat" */))
const _3b9607f7 = () => interopDefault(import('../pages/articles/edit/index.vue' /* webpackChunkName: "pages/articles/edit/index" */))
const _0c6008f4 = () => interopDefault(import('../pages/article/edit/_id.vue' /* webpackChunkName: "pages/article/edit/_id" */))
const _2eb29951 = () => interopDefault(import('../pages/user/edit/_id.vue' /* webpackChunkName: "pages/user/edit/_id" */))
const _490d9479 = () => interopDefault(import('../pages/article/_id.vue' /* webpackChunkName: "pages/article/_id" */))
const _183188ac = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/login",
    component: _84e2427e,
    name: "login"
  }, {
    path: "/article/creat",
    component: _80b033f0,
    name: "article-creat"
  }, {
    path: "/articles/edit",
    component: _3b9607f7,
    name: "articles-edit"
  }, {
    path: "/article/edit/:id?",
    component: _0c6008f4,
    name: "article-edit-id"
  }, {
    path: "/user/edit/:id?",
    component: _2eb29951,
    name: "user-edit-id"
  }, {
    path: "/article/:id?",
    component: _490d9479,
    name: "article-id"
  }, {
    path: "/",
    component: _183188ac,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
