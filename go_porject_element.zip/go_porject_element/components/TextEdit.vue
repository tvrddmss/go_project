<template>
  <div class="TextEdit">
    <el-row style="width: 100%">
      <el-col :span="4">
        <a>{{ label }}</a>
      </el-col>
      <el-col :span="20">
        <el-input
          style="width: 99%"
          type="text"
          v-model="thisvalue"
          :disabled="disabled"
          @input="inputChange"
        />
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  props: {
    label: {
      type: String,
      default: "",
    },
    value: {
      type: String,
      default: "",
    },
    disabled: "",
  },
  data() {
    return {
      thisvalue: this.value,
    };
  },
  watch: {
    value() {
      this.thisvalue = this.value;
    },
  },
  methods: {
    inputChange() {
      this.$emit("inputchange", this.thisvalue);
    },
  },
  head() {
    // Set Meta Tags for this Page
  },
};
</script>

<style scoped>
.TextEdit {
  display: flex;
  flex-direction: row;
  height: 40px;
  /* justify-content: center; */
  align-items: center;
  align-content: space-between;
  width: 100%;
  margin-top: 5px;
  margin-bottom: 5px;
}
.TextEdit label {
  width: 30%;
}
.TextEdit input {
  width: 70%;
}
</style>
