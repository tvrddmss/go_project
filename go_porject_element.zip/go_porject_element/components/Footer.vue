<template>
  <footer class="footer">获取账户，请联系：weishuolin@163.com</footer>
</template>
<style scoped>
/* 状态栏 */
.footer {
  display: flex;
  position: fixed;
  bottom: 0px;
  left: 0px;
  height: fit-content;
  width: 100%;
  background-color: gray;
  justify-content: center;
  flex-direction: row;
  align-items: center;

  border-top-color: rgb(224, 224, 224);
  border-top-width: 1px;
  border-style: groove;
  border-bottom: none;
  border-left: none;
  border-right: none;
}
</style>