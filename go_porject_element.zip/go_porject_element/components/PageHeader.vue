<template>
  <div class="navigation">
      <div class="title">
        <nuxt-link to="/">
          <img class="img_icon" src="~/assets/images/icon.png" ></img>
        </nuxt-link>
        <div class="center">诡异故事分享</div>        
        <span v-if="token!=''" style="display:flex;">
          <div style="padding-right: 20px;cursor: pointer;" @click="newArticle">新建</div>
          <div style="padding-right: 20px;cursor: pointer;" @click="myArticle">我的博客</div>
          <span class="nickname">{{userinfo.nickname}}</span>
        </span>
        <div class="log">
        <div v-if="token!=''"  @click="logout">注销</div>
        <div v-else class="item" @click="login">登陆</div>
        </div>
        <div class="userimg" @click="transformUserInfo" >
          <img v-if="userinfo.img==''" class="img_icon"  src="~/assets/images/user.png" ></img>
          <img v-else class="img_icon" :src="userinfo.img"  ></img>
        </div>
    </div>
  </div>
</template>

<script>
import { getToken } from "@/utils/auth";
import { getUserInfo } from "@/utils/auth";
export default {
  props: {
    // data: {
    //   type: Object,
    //   default() {
    //     return {
    //       id: "",
    //       img: "",
    //     };
    //   },
    //   required: false,
    // },
  },
  data() {
    return {
      token: "",
      userinfo: "",
    };
  },

  mounted() {
    debugger;
    this.refresh();
  },

  methods: {
    //refresh
    refresh() {
      this.token = getToken();
      this.userinfo = getUserInfo();
    },
    transformUserInfo() {
      this.$router.push({
        name: "user-edit-id",
        query: { id: this.userinfo.id },
      });
    },
    login() {
      this.$router.push({
        name: "login",
      });
      return;
    },
    logout() {
      this.$store.commit("setLogout", null);
      //判断当前页面，如果是用户页面，跳到首页
      if ($nuxt.$route.name == "user-edit-id") {
        this.$router.push("/");
      }
    },
    //新发博客
    newArticle() {
      this.$router.push({
        name: "article-creat",
      });
    },
    //我的文章
    myArticle() {
      this.$router.push({
        name: "articles-edit",
      });
    },
  },
  head() {
    // Set Meta Tags for this Page
    return {
      //link: [{ rel: "stylesheet", href: "/css/title.css" }],
    };
  },
};
</script>

<style scoped>
/* 导航栏 */
.navigation {
  display: flex;
  position: fixed;
  top: 0px;
  left: 0px;
  height: inherit;
  width: 100%;
  background-color: gray;
  border-bottom-color: rgb(224, 224, 224);
  border-bottom-width: 1px;
  border-style: groove;
  border-top: none;
  border-left: none;
  border-right: none;
  z-index: 20;
  justify-content: center;
  align-items: center;
  white-space: nowrap;
}

.navigation .title {
  display: flex;
  flex-direction: row;
  align-items: center;
  width: 1114px;
}
.navigation .title .img_icon {
  /* background-image: require("~/static/images/icon.png") no-repeat; */
  /* background-size: 30px; */
  height: 30px;
  width: 30px;
}
.navigation .title .center {
  flex-grow: 1;
}
.navigation .title .nickname {
  padding-right: 20px;
}
.navigation .title .log {
  padding-right: 20px;
  cursor: pointer;
}
.navigation .title .userimg {
  cursor: pointer;
}
</style>
