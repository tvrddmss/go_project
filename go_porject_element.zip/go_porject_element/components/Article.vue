<template>
  <div class="article">
    <h1 class="article-title">
      <div>{{ data.title }}</div>
      <div class="tag">{{ data.tag.name }}</div>
    </h1>
    <div v-html="data.content"></div>
  </div>
</template>

<script>
export default {
  props: {
    data: {
      type: Object,
      default() {
        return {};
      },
      required: false,
    },
  },
  head() {
    return {
      //link: [{ rel: "stylesheet", href: "/css/articlelist.css" }],
    };
  },
};
</script>
<style scoped>
.tag {
  margin-left: 100px;
}
</style>
