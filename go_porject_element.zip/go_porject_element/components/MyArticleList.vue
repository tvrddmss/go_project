<template>
  <ul style="margin-top: 0px; margin-left: 10px; padding-left: 0px">
    <span v-for="(article, index) in articles" :key="article.id">
      <el-card style="margin-bottom: 10px">
        <el-row style="width: 100%">
          <el-col :span="4">
            <a style="color: black; text-decoration: none">
              {{ article.title }}
            </a>
          </el-col>
          <el-col :span="16"> &nbsp; </el-col>
          <el-col :span="4" style="text-align: right">
            <el-link type="danger" @click="editArticle(article)">编辑</el-link>
            <el-link type="danger" @click="deleteArticle(article)"
              >删除</el-link
            >
          </el-col>
          <el-col :span="24">
            <el-tag>{{ article.tag.name }} </el-tag>
          </el-col>
          <el-col :span="24">
            <div class="article-content">{{ article.desc }}</div>
          </el-col>
        </el-row>
      </el-card>
    </span>
  </ul>
</template>

<script>
export default {
  props: {
    articles: {
      type: Array,
      default() {
        return [];
      },
      required: false,
    },
  },
  head() {
    return {
      //link: [{ rel: "stylesheet", href: "/css/articlelist.css" }],
    };
  },
  methods: {
    //编辑
    editArticle(event) {
      this.$router.push({ name: "article-edit-id", params: { id: event.id } });
    },
    //删除
    deleteArticle(event) {
      this.$emit("deleteArticle", event);
    },
  },
};
</script>
<style scoped>
.article-title {
  font-size: 20px;
  display: flex;
  color: #333333;
  flex-direction: row;
  text-decoration: none;

  justify-content: baseline;
  align-items: baseline;
}
.article-title .article-title-tag {
  margin-left: 100px;
  font-size: 15px;
  color: #333333;
  text-decoration: none;
}
.article-content {
  max-height: 100px;
  word-wrap: break-word;
  /* padding-right: 10px; */
  /* padding-bottom: 10px; */
}
</style>
