<template>
  <div>
    <section class="container">
      <quill-editor
        class="quill-editor"
        v-if="isClient"
        v-model="content"
        ref="RichEdit"
        :options="editorOption"
        @blur="onEditorBlur($event)"
        @focus="onEditorFocus($event)"
        @ready="onEditorReady($event)"
        @change="onEditorChange($event)"
      >
      </quill-editor>
    </section>
  </div>
</template>

<script>
import "quill/dist/quill.core.css";
import "quill/dist/quill.snow.css";
import "quill/dist/quill.bubble.css";

export default {
  props: {
    propscontent: {
      type: String,
      default: "",
    },
    disabled: "",
  },
  data() {
    return {
      isClient: false,
      content: this.propscontent,
      editorOption: {
        // some quill options
        modules: {
          // toolbar: true
          toolbar: [
            ["bold", "italic", "underline", "strike"], // 加粗 斜体 下划线 删除线
            ["blockquote", "code-block"], // 引用  代码块
            [{ header: 1 }, { header: 2 }], // 1、2 级标题
            [{ list: "ordered" }, { list: "bullet" }], // 有序、无序列表
            [{ script: "sub" }, { script: "super" }], // 上标/下标
            [{ indent: "-1" }, { indent: "+1" }], // 缩进
            [{ direction: "rtl" }], // 文本方向
            [
              {
                size: [
                  "12",
                  "14",
                  "16",
                  "18",
                  "20",
                  "22",
                  "24",
                  "28",
                  "32",
                  "36",
                ],
              },
            ], // 字体大小
            [{ header: [1, 2, 3, 4, 5, 6] }], // 标题
            [{ color: [] }, { background: [] }], // 字体颜色、字体背景颜色
            // [{ font: ['songti'] }], // 字体种类
            [{ align: [] }], // 对齐方式
            ["clean"], // 清除文本格式
            ["image", "video"], // 链接、图片、视频
          ],
        },
      },
    };
  },
  mounted() {
    //console.log("app init, my quill insrance object is:", this.myQuillEditor);
    // setTimeout(() => {
    //   this.content = 'i am changed'
    // }, 3000)
    if (process.client) {
      const { quillEditor } = require("vue-quill-editor");
      this.$options.components = { quillEditor };
      this.isClient = true;
    }
  },
  methods: {
    onEditorBlur(editor) {
      // console.log('editor blur!', editor)
    },
    onEditorFocus(editor) {
      // console.log('editor focus!', editor)
    },
    onEditorReady(editor) {
      // for (var i = 0; i < 20; i++) {
      //   this.content += "<p><br /></p>";
      // }
    },
    onEditorChange({ editor, html, text }) {
      debugger;
      this.$emit("onChange", html);
    },
  },
};
</script>
<style  scoped>
.container {
  width: 100%;
  /* margin: 0 0 0 20px; */
  /* padding: 20px 0px; */
  margin-top: 10px;
  margin-bottom: 10px;
  padding-bottom: 15px;
  background-color: #ffffff;
}
.quill-editor {
  height: 500px;
  margin-bottom: 30px;
}
</style>
