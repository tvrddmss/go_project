
const state = {
    //token: getToken(),
    name: "",
    avatar: "",
    introduction: "",
    roles: [],
};

const mutations = {
    SET_TOKEN: (state, token) => {
        state.token = token;
    },
    SET_INTRODUCTION: (state, introduction) => {
        state.introduction = introduction;
    },
    SET_USER_ID: (state, id) => {
        state.id = id;
    },
    SET_NAME: (state, name) => {
        state.name = name;
    },
    SET_AVATAR: (state, avatar) => {
        state.avatar = avatar;
    },
    SET_ROLES: (state, roles) => {
        state.roles = roles;
    },
};

const baseurl = "http://192.168.50.8:3001/go_project";
const actions = {
    // user login
    login({ commit }, loginForm) {
        const { username, password } = loginForm;
        return new Promise((resolve, reject) => {
            this._vm.axios
                .form(baseurl + '/auth', {
                    username,
                    password,
                })
                .then((data) => {
                    commit("SET_TOKEN", data.token);
                    setToken(data.token);
                    resolve();
                })
                .catch((error) => {
                    reject(error);
                });
        });
    },
};

export default {
    namespaced: true,
    state,
    mutations,
    actions,
};
