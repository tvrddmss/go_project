// 导入Base64
import { Base64 } from 'js-base64'
import { setToken } from "@/utils/auth";
import { removeToken } from '../utils/auth';
import { setUserInfo } from "@/utils/auth";
import { removeUserInfo } from '../utils/auth';

// 设定需要储存的数据及其默认值
export const state = () => ({
    token: '',
    userinfo: {
        id: '',
        username: '',
        userip: '',
        nickname: '',
        img: '',
    },
})

// 获取数据方法
export const getters = {
    getToken(state) {
        return state.token
    }
}

//更新数据方法
export const mutations = {
    setUserInfo(state, userinfo) {
        if (userinfo.token && userinfo.token != "") {
            state.token = userinfo.token
        }
        state.userinfo.id = userinfo.id
        state.userinfo.username = userinfo.username
        state.userinfo.nickname = userinfo.nickname
        state.userinfo.img = userinfo.img;
        // var millisecond = new Date().getTime();
        // var expiresTime = new Date(millisecond + 60 * 1000 * 10);
        // this.$cookies.set("token", userinfo.token, { expires: expiresTime });
        setToken(state.token);
        //this.$cookies.set("userinfo", userinfo, { expires: expiresTime });
        setUserInfo(userinfo);
    },
    setLogout(state, userinfo) {
        state.token = ""
        state.userinfo.id = ""
        state.userinfo.username = ""
        state.userinfo.nickname = ""
        state.userinfo.img = ""
        // this.$cookies.remove("token");
        //this.$cookies.remove("userinfo");
        removeToken();
        removeUserInfo();
    },
    setHeader(state, headers) {
        state.headers = headers
        state.userip = headers["x-real-ip"]
    },
    setToken(state, token) {
        state.token = token;
    },
}
// 初始化数据方法
export const actions = {
    // nuxtServerInit，用以初始化数据
    async nuxtServerInit({ commit }, { app, req, route }) {
        debugger;
        // const token = app.$cookies.get('token')
        // const id = app.$cookies.get('EFFECTIVE_UUID')
        // commit('setHeader', req.headers)
        // const userinfo = app.$cookies.get('userinfo')
        // //console.log(userinfo);
        // if (userinfo != undefined) {
        //     commit('setUserInfo', userinfo)
        // }

        // const region = await getUserRegionByIp(app, req.headers);
        // console.log('getUserRegionByIp', region);
        // const token = {}
        // // 从cookie中获取token，并且将其中的数据更新到store
        // token.Authorization = app.$cookies.get('Authorization')
        // // 如果存在token
        // if (token.Authorization) {
        //     // 解析token中携带的用户信息
        //     const info = JSON.parse(Base64.decode(token.Authorization.split('.')[1]))
        //     token.username = info.username
        //     token.id = info.id
        //     // 将用户信息更新
        //     // commit用以提交需要更新的数据，并指定更新的方法
        //     commit('setToken', token)
        // }
    }
}

// import user from './modules/user'
// export const modules = {
//     user1: user
// }