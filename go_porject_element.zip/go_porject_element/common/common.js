baseInfo = function () {
    that = {

    }
    return that;
}();