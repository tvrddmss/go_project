import Cookies from "js-cookie";

const TokenKey = "token";
const UserInfoKey = "userinfo";

export function getToken() {
    let token = Cookies.get(TokenKey);
    if (token == undefined) {
        token = "";
    }
    if (token == "undefined") {
        token = "";
    }
    console.log(token);
    return token;
}

export function setToken(token) {
    var millisecond = new Date().getTime();
    var expiresTime = new Date(millisecond + 60 * 1000 * 10);
    return Cookies.set(TokenKey, token, { expires: expiresTime });
}

export function removeToken() {
    return Cookies.remove(TokenKey);
}

export function setUserInfo(userinfo) {
    var millisecond = new Date().getTime();
    var expiresTime = new Date(millisecond + 60 * 1000 * 10);
    return Cookies.set(UserInfoKey, JSON.stringify(userinfo), { expires: expiresTime });
}

export function getUserInfo() {
    let userinfoStr = Cookies.get(UserInfoKey);
    if (userinfoStr != undefined && userinfoStr != "undefined") {
        return JSON.parse(userinfoStr);
    }
    else {
        return {
            id: '',
            username: '',
            userip: '',
            nickname: '',
            img: '',
        };
    }
}
export function removeUserInfo() {
    let userinfoStr = Cookies.get(UserInfoKey);
    if (userinfoStr != undefined && userinfoStr != "undefined") {
        Cookies.remove(userinfoStr)
    }
    return;
}
