import axios from 'axios';
import { getToken } from "@/utils/auth";
import store from "@/store";
//import router from '../router';

axios.defaults.timeout = 60000; //请求超时10秒
//axios.defaults.baseURL =''; //请求base url
axios.defaults.headers.post['Content-Type'] = 'application/json'; //设置post请求是的header信息

//如果你要用到session验证码功能，让请求携带cookie
axios.defaults.withCredentials = true

// request interceptor
axios.interceptors.request.use(
    (config) => {
        // if (store.getters.token) {
        config.headers["token"] = getToken();
        // }
        // // 如果是form请求
        // if (isFormData(config.data)) {
        //     delete config.data[formatFormDataKey];
        //     config.data = qs.stringify(config.data); // 转为formdata数据格式
        // }
        return config;
    },
    (error) => Promise.reject(error)
);

/**
 * 封装get方法
 * @param url
 * @param data
 * @returns {Promise}
 */

export default {
    // setAxiosLocalIp(ip) {
    //     axios.defaults.headers["x-real-ip"] = ip
    // },
    // setAxios(userinfo) {
    //     axios.defaults.headers.token = userinfo.token
    //     axios.defaults.headers.username = userinfo.username
    //     axios.defaults.headers["x-real-ip"] = userinfo.userip
    // },




    requestGetAuth(url, params = {}) {
        return new Promise((resolve, reject) => {
            axios.get(url, { params: params }).then(response => {
                resolve(response.data);
            }).catch(error => {
                reject(error)
            })
        })
    },
    //get请求
    requestGet(url, params = {}) {
        //axios.defaults.headers.token = config.headers.token
        return new Promise((resolve, reject) => {
            axios.get(url, params).then(response => {
                resolve(response.data);
            }).catch(error => {
                reject(error)
            })
        })
    },

    //post请求
    requestPost(url, params = {}) {
        //axios.defaults.headers.token = config.headers.token
        return new Promise((resolve, reject) => {
            axios.post(url, params).then(response => {
                resolve(response.data);
            }).catch(error => {
                reject(error)
            })
        })
    },

    //delete请求
    requestDelete(url, params = {}) {
        //axios.defaults.headers.token = config.headers.token
        return new Promise((resolve, reject) => {
            axios.delete(url, params).then(response => {
                resolve(response.data);
            }).catch(error => {
                reject(error)
            })
        })
    },

    //put请求
    requestPut(url, params = {}) {
        return new Promise((resolve, reject) => {
            axios.put(url, params).then(response => {
                resolve(response.data);
            }).catch(error => {
                reject(error)
            })
        })
    },

    //上传文件
    requestPostFile(url, formdata) {
        axios.defaults.headers["Content-Type"] = "multipart/form-data;boundary=" + new Date().getTime()
        return new Promise((resolve, reject) => {
            axios.post(url, formdata).then(response => {
                resolve(response.data);
            }).catch(error => {
                reject(error)
            })
        })

    },

}