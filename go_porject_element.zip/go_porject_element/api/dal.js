//导入自己编写封装的http.js文件
import http from "./http";
const baseurl = "http://192.168.50.8:3001/go_project";

export const getAuthLogin = (params) => {
  return http.requestGetAuth(baseurl + '/auth/login', params);
}
// //
// export const setAxios = (userinfo) => {
//   return http.setAxios(userinfo);
// }
// export const setAxiosLocalIp = (ip) => {
//   return http.setAxiosLocalIp(ip);
// }
//例如：get请求
export const getLink = (url, params) => {
  return http.requestGet(baseurl + url, params);
}

//例如：post请求
export const addLink = (url, params) => {
  return http.requestPost(baseurl + url, params);
}

//例如：put请求
export const updateLink = (url, params) => {
  return http.requestPut(baseurl + url, params);
}

//例如：delete请求
export const deleteLink = (url, params) => {
  return http.requestDelete(baseurl + url, params);
}

//上传文件
export const postFileLink = (url, formdata) => {
  return http.requestPostFile(baseurl + url, formdata);
}

