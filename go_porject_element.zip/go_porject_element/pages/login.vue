<template>
<div>
<el-container>
  <el-header><PageHeader :data="userinfo" /></el-header>
  <el-main>
    <div class="content">
      <div class="center">
          <el-row class="loginContentContent">
            <el-col :span="16" class="col_left">
              <img class="loginImg" src="~/assets/images/login.png"></img> 
            </el-col>
            <el-col :span="8" >
              <div class="form-group">
                <el-input
                  v-model="username"
                  type="email"
                  id="exampleInputEmail1"
                  placeholder="邮箱"
                />
              </div>
              <div class="form-group">
                <el-input
                  v-model="password"
                  type="password"
                  id="exampleInputPassword1"
                  placeholder="密码"
                />
              </div>
              <el-button @click="login_click" style="width:100%;"> 登陆 </el-button>
            </el-col>
          </el-row>
      </div>
    </div>
  </el-main>
  <el-footer><Footer /></el-footer> 
</el-container>
</div>
</template>
<script>
import { getAuthLogin } from "../api/dal";
import PageHeader from "~/components/PageHeader.vue";
import Footer from "~/components/Footer.vue";
export default {
  layout: "none",
  components: {
    PageHeader,
    Footer,
  },
  // page component definitions
  asyncData(content) {
    // let data = {};
    // data.userinfo = content.store.state.userinfo;
    // //data.state = content.store.state;
    // return data;
  },
  data() {
    return {
      userinfo: {
        id: this.$store.state.userinfo.id,
        username: this.$store.state.userinfo.username,
        userip: this.$store.state.userinfo.userip,
        nickname: this.$store.state.userinfo.nickname,
        img: this.$store.state.userinfo.img,
      },
      username: "",
      password: "",
    };
  },
  mounted() {
    const that = this;
    document.addEventListener("keydown", that.HashChangeEvent);
  },
  fetch() {
    // The fetch method is used to fill the store before rendering the page
  },
  head() {
    // Set Meta Tags for this Page
    return {
      link: [{ type: "text/javascript", src: "~/common/common.js" }],
    };
  },
  methods: {
    //键盘事件
    HashChangeEvent(e) {
      var key = window.event ? e.keyCode : e.which;
      if (key === 13) {
        this.login_click();
      }
    },
    //登陆
    async login_click() {
      if (!this.username) {
        this.$message.error("请输入用户名或邮箱");
        return;
      }
      if (!this.password) {
        this.$message.error("请输入密码");
        return;
      }
      return getAuthLogin({
        username: this.username,
        password: this.password,
      }).then((result) => {
        this.$store.commit("setUserInfo", result.data);
        this.userinfo = result.data;
        this.login_success(result.data);
        //直接跳转
        this.$router.push("/");
        return;
      });
    },

    login_success(userinfo) {
      //localStorage.setItem("token", userinfo.token);
    },
  },
};
</script>
<style  scoped>
.content {
  /* margin-top: 50px; */
  display: flex;
  justify-content: center;
  align-items: center;
}
.content .center {
  padding-top: 10px;
  width: 1114px;
  display: flex;
  flex-direction: row;
}
.content .center .loginContentContent {
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}
.content .center .loginContentContent .form-group {
  margin-bottom: 10px;
}
.content .center .loginContentContent .col_left {
  display: flex;
  justify-content: center;
  align-items: center;
}
.content .center .loginContentContent .col_left img {
  width: 400px;
  height: 400px;
}
.content .center .loginContentContent .col_right {
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>