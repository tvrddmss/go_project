<template>
  <!-- Your template -->
  <div>
    <el-container>
      <el-header> <PageHeader :data="userinfo" /></el-header>
      <el-main>
        <div class="content">
          <div class="center">
            <Article :data="model"></Article>
          </div>
        </div>
      </el-main>
      <el-footer> <Footer /></el-footer>
    </el-container>
  </div>
</template>
<script>
import { getLink } from "~/api/dal";
import Article from "~/components/Article.vue";
import PageHeader from "~/components/PageHeader.vue";
import Footer from "~/components/Footer.vue";
export default {
  layout: "none",
  components: {
    Article,
    PageHeader,
    Footer,
  },
  validate({ params }) {
    // 必须是number类型
    return /^\d+$/.test(params.id);
  },
  // page component definitions
  asyncData(content) {
    // called every time before loading the component
    return getLink("/api/v1/articles/" + content.params.id, {}).then(
      (result) => {
        let data = {};
        data.model = result.data;
        data.userinfo = content.store.state.userinfo;
        return data;
      }
    );
  },
  fetch() {
    // The fetch method is used to fill the store before rendering the page
  },
  data() {
    return {
      model: {},
      userinfo: {},
    };
  },
  head() {
    // Set Meta Tags for this Page
  },
};
</script>
<style>
</style>