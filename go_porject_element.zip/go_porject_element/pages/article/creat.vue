<template>
  <!-- Your template -->
  <div>
    <el-container>
      <el-header><PageHeader :data="userinfo" /></el-header>
      <el-main>
        <div class="content">
          <div class="center">
            <div style="width: 100%">
              <el-form
                ref="form"
                :model="model"
                label-position="left"
                label-width="80px"
              >
                <el-form-item label="标题">
                  <el-input v-model="model.title"></el-input>
                </el-form-item>
                <el-form-item label="简介">
                  <el-input v-model="model.desc"></el-input>
                </el-form-item>
                <el-form-item label="标签">
                  <TagEdit></TagEdit>
                </el-form-item>
                <RichEdit
                  :propscontent="model.content"
                  @onChange="onRichEditChange"
                />
                <el-form-item style="text-align: right">
                  <el-button type="primary" @click="onSubmit">保存</el-button>
                  <el-button @click="onCancle">取消</el-button>
                </el-form-item>
              </el-form>
            </div>
          </div>
        </div>
      </el-main>
      <el-footer> <Footer /></el-footer>
    </el-container>
  </div>
</template>
<script>
import { addLink } from "~/api/dal";
import PageHeader from "@/components/PageHeader.vue";
import Footer from "@/components/Footer.vue";
import TextEdit from "@/components/TextEdit.vue";
import RichEdit from "@/components/RichEdit"; //导入组件
import TagEdit from "@/components/TagEdit"; //导入组件
export default {
  layout: "none",
  //使用middleware引入中间件
  middleware: "auth",
  components: {
    PageHeader,
    Footer,
    TextEdit,
    RichEdit,
    TagEdit,
  },
  //   validate({ params }) {
  //     // 必须是number类型
  //     return /^\d+$/.test(params.id);
  //   },
  // page component definitions
  asyncData(content) {
    // called every time before loading the component
    // return getLink(
    //   "/api/v1/articles/" + content.params.id,
    //   content.store.state,
    //   {}
    // ).then((result) => {
    //   console.log(result);
    //   return { model: result.data };
    // });
    // return { userinfo: content.store.state.userinfo };
  },
  fetch() {
    // The fetch method is used to fill the store before rendering the page
  },
  data() {
    return {
      model: {
        tagId: 1,
        title: "",
        content: "",
        desc: "",
        createdBy: "",
        state: 0,
      },
    };
  },
  head() {
    // Set Meta Tags for this Page
  },
  methods: {
    onRichEditChange(value) {
      debugger;
      this.model.content = value;
    },
    //提交
    onSubmit() {
      this.model.createdBy = this.$store.state.userinfo.id;
      let formData = new FormData();
      for (let key in this.model) {
        formData.append(key, this.model[key]);
      }
      addLink("/api/v1/articles", formData).then((result) => {
        console.log(result);
        if (result.code == 200) {
          this.$message({
            message: "保存成功",
            type: "success",
          });
          //直接跳转
          this.$router.push("/");
        } else {
          this.$message.error(result.msg);
        }
      });
    },
    //取消
    onCancle() {
      //this.$router.go(-1); //返回上一页
      //this.$router.back('/'); //回到首页
      //this.$router.push('/'); //跳回首页
      this.$router.push({ name: "index" });
    },
  },
};
</script>
<style>
.red {
  color: red;
}
</style>