<template>
  <!-- Your template -->
  <div>
    <el-container>
      <el-header><PageHeader :data="userinfo" ref="pageheader" /></el-header>
      <el-main>
        <div class="content">
          <div class="center">
            <el-form
              ref="form"
              :model="userinfo"
              label-position="left"
              label-width="80px"
              style="width: 100%"
            >
              <el-form-item label="用户头像">
                <div>
                  <el-image
                    style="width: 100px; height: 100px"
                    :src="userinfo.img"
                    fit="fit"
                    @click="selectfile"
                  ></el-image>
                </div>
                <input
                  style="display: none"
                  type="file"
                  id="upload"
                  name="upload"
                  @change="filechange"
                />
              </el-form-item>
              <el-form-item label="用户ID">
                <el-input v-model="userinfo.id" :disabled="true"></el-input>
              </el-form-item>
              <el-form-item label="登陆名">
                <el-input
                  v-model="userinfo.username"
                  :disabled="true"
                ></el-input>
              </el-form-item>
              <el-form-item label="用户昵称">
                <el-input v-model="userinfo.nickname"></el-input>
              </el-form-item>

              <el-form-item style="text-align: right">
                <el-button type="primary" @click="onSubmit">保存</el-button>
                <el-button @click="onCancle">取消</el-button>
              </el-form-item>
            </el-form>
          </div>
        </div>
      </el-main>
      <el-footer> <Footer /></el-footer>
    </el-container>
  </div>
</template>
<script>
import { getLink } from "~/api/dal";
import { postFileLink } from "~/api/dal";
import { updateLink } from "~/api/dal";
import PageHeader from "~/components/PageHeader.vue";
import Footer from "~/components/Footer.vue";
import TextEdit from "~/components/TextEdit.vue";

export default {
  layout: "none",
  //使用middleware引入中间件
  middleware: "auth",
  components: {
    PageHeader,
    Footer,
    TextEdit,
  },
  // page component definitions
  asyncData(content) {},
  fetch() {
    // The fetch method is used to fill the store before rendering the page
    //this.getdata();
  },
  data() {
    return {
      userinfo: {
        id: this.$store.state.userinfo.id,
        username: this.$store.state.userinfo.username,
        userip: this.$store.state.userinfo.userip,
        nickname: this.$store.state.userinfo.nickname,
        img: this.$store.state.userinfo.img,
      },
    };
  },
  head() {
    // Set Meta Tags for this Page
    return {
      link: [{ type: "text/javascript", src: "~/common/common.js" }],
    };
  },
  mounted() {
    let _self = this;
    _self.getData();
  },
  methods: {
    //选择文件
    selectfile() {
      document.getElementById("upload").click();
    },
    //选择完文件
    filechange() {
      let files = document.getElementById("upload").files;
      if (files.length > 0) {
        this.uploadfile();
      }
    },
    //上传文件
    uploadfile() {
      let _self = this;
      let file = document.getElementById("upload").files[0];
      let formData = new FormData();
      formData.append("imgfile", file, file.name);
      formData.append("id", this.userinfo.id);

      return postFileLink("/auth/uploadimg", formData).then((result) => {
        console.log(result);
        _self.getData();
        return;
      });
    },
    //获取数据
    getData() {
      let _self = this;
      getLink("/auth/" + this.userinfo.id, {}).then((result) => {
        _self.refreshPage(result);
      });
    },
    //提交数据
    onSubmit() {
      let _self = this;
      let formData = new FormData();
      formData.append("nickname", this.userinfo.nickname);
      updateLink("/auth/" + this.userinfo.id, formData).then((result) => {
        _self.refreshPage(result);

        // debugger;
        // _self.$store.state.userinfo.nickname = result.data.nickname;
        // _self.$store.state.userinfo.img = result.data.img;

        this.$message({
          message: "保存成功",
          type: "success",
        });
      });
    },
    refreshPage(result) {
      this.userinfo = result.data;
      this.$store.commit("setUserInfo", result.data);
      this.$refs.pageheader.refresh();
    },
    //取消
    onCancle() {
      //this.$router.go(-1); //返回上一页
      //this.$router.back('/'); //回到首页
      //this.$router.push('/'); //跳回首页

      this.$router.push({ name: "index" });
    },
  },
};
</script>
<style>
</style>