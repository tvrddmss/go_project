<template>
  <!-- Your template -->
  <div>
    <el-container>
      <el-header><PageHeader :data="userinfo" /></el-header>
      <el-main>
        <div class="content">
          <div class="center">
            <el-row>
              <el-col :span="4">
                <el-card>
                  <el-row>
                    <el-col :span="24" style="cursor: pointer">
                      <li class="el-icon-chat-line-square">默认分组</li>
                    </el-col>
                  </el-row>
                </el-card>
              </el-col>
              <el-col :span="20">
                <MyArticleList
                  :articles="lists"
                  @deleteArticle="deleteArticle"
                />
              </el-col>
            </el-row>
          </div>
        </div>
      </el-main>
      <el-footer> <Footer /></el-footer>
    </el-container>
  </div>
</template>
<script>
import { getLink } from "~/api/dal";
import { deleteLink } from "~/api/dal";
import MyArticleList from "~/components/MyArticleList.vue";
import PageHeader from "~/components/PageHeader.vue";
import Footer from "~/components/Footer.vue";
export default {
  layout: "none",
  //使用middleware引入中间件
  middleware: "auth",
  // page component definitions
  components: {
    MyArticleList,
    PageHeader,
    Footer,
  },
  asyncData(content) {},
  fetch() {
    // The fetch method is used to fill the store before rendering the page
  },
  data() {
    return {
      lists: [],
      total: 0,
      page: 0,
      state: "0",
      userinfo: this.$store.state.userinfo,
    };
  },
  head() {
    // Set Meta Tags for this Page
    return {
      //link: [{ rel: "stylesheet", href: "/css/title.css" }],
    };
  },
  methods: {
    //获取数据
    getData() {
      getLink("/api/v1/articles", {
        state: this.state,
        page: this.page,
        created_by: this.$store.state.userinfo.id,
      }).then((result) => {
        this.total = result.data.total;
        for (let key in result.data.lists) {
          this.lists.push(result.data.lists[key]);
        }
      });
    },
    deleteArticle(article) {
      deleteLink("/api/v1/articles/" + article.id, {}).then((result) => {
        if (result.code == 200) {
          this.$message({
            message: "保存成功",
            type: "success",
          });
          this.page = 1;
          this.total = 0;
          this.lists = [];
          this.getData();
        } else {
          this.$message.error(result.msg);
        }
      });
    },
  },
  mounted() {
    let that = this;
    that.page = that.page + 1;
    that.getData();
    this.$nextTick(() => {
      // this.initScroll()
      window.onscroll = function () {
        //变量scrollTop是滚动条滚动时，距离顶部的距离
        var scrollTop =
          document.documentElement.scrollTop || document.body.scrollTop;
        //变量windowHeight是可视区的高度
        var windowHeight =
          document.documentElement.clientHeight || document.body.clientHeight;
        //变量scrollHeight是滚动条的总高度
        var scrollHeight =
          document.documentElement.scrollHeight || document.body.scrollHeight;
        //滚动条到底部的条件
        if (scrollTop + windowHeight == scrollHeight) {
          if (that.total > that.lists.length) {
            //写后台加载数据的函数 一定要用that
            that.page = that.page + 1;
            that.getData();
          }
        }
      };
    });
  },
};
</script>
<style>
.content .center .left {
  width: 182px;
  min-height: 600px;
  margin-right: 10px;
  background-color: white;
  border-radius: 5px;
  border-color: grey;
  border-width: 2px;
}
.content .center .right {
  width: 932px;
  min-height: 600px;
  /* background-color: white;
    border-radius: 5px;
    border-color: grey;
    border-width: 2px; */
}

.article-list {
  margin: 0 !important;
}
.article-list li {
  /* padding: 12px 12px; */
  display: flex;
  position: relative;
  overflow: hidden;
  border-radius: 3px;
  background: var(--bg-color);
}

.article-list {
  padding-left: 0px;
  /*  padding-right: 10px; */
}

.article {
  margin-bottom: 10px;
  width: 100%;
  border-radius: 10px;
  background-color: white;
  border-radius: 5px;
  border-color: grey;
  border-width: 2px;
  padding: 20px;
}
.article .article-title {
  font-size: 20px;
  display: flex;
  color: #333333;
  flex-direction: row;
  text-decoration: none;

  justify-content: baseline;
  align-items: baseline;
}
.article .article-title .article-title-tag {
  margin-left: 100px;
  font-size: 15px;
  color: #333333;
  text-decoration: none;
}
</style>