export default {
    server: {
        port: 3000, // default: 3000
        host: '0.0.0.0' // default: localhost
    },
    // other configs
    modules: [
        'cookie-universal-nuxt'
    ],
    plugins: [{
        src: '~plugins/element-ui',
        ssr: false //是能在服务端运行
    }],
    build: {
        vendor: ['element-ui'],

    },

}